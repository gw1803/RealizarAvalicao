export class QuestaoElegivel {
    idQuestaoElegivel:number;
    numeroParteFixo: number;
    tipoConhecimento: string;
    sentidoIdentificacao: string;
    grupoQuestaosId: number;
}
