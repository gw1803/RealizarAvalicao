import { Peca } from './peca';

describe('Peca', () => {
  it('should create an instance', () => {
    expect(new Peca()).toBeTruthy();
  });
});
