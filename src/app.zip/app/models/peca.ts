export class Peca {
    idPeca: number;
    sentido: string;
    nomePeca: string;
    idRoteiro: string;
    
}
