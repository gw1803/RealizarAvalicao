import { Parte } from './parte';

describe('Parte', () => {
  it('should create an instance', () => {
    expect(new Parte()).toBeTruthy();
  });
});
