import { QuestaoSorteada } from './questao-sorteada';

describe('QuestaoSorteada', () => {
  it('should create an instance', () => {
    expect(new QuestaoSorteada()).toBeTruthy();
  });
});
