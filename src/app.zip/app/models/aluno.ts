import * as internal from "stream";

export class Aluno {
    matriculaAluno: number;
    nomeAluno: string;
    cpfAluno: string;
    enderecoAluno:string;
    telefoneAluno: number;
    cepAluno: number;
    dataNascimentoAluno: String;
}
