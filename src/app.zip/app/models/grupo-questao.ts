export class GrupoQuestao {
    idGrupoQuestao:number;
    nomeGrupo: string;
    pontoPorQuestao: number;
    quantidadeParaSortear:number;
}
