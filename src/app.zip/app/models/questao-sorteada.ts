export class QuestaoSorteada {
    idQuestaoSorteada: number;
    numeroParteSorteada: number;
    comentarioProfessor: string;
    notaCorrecao: number;
    tempoGasto: string;
    respostaNumeroParte: number;
    respostaNome: string;
    respostaConhecimento: string;
    matriculaAluno:number;
    questaoElegivels:number;
    idAvaliacao:number;

}
