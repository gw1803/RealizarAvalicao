import { QuestaoElegivel } from './questao-elegivel';

describe('QuestaoElegivel', () => {
  it('should create an instance', () => {
    expect(new QuestaoElegivel()).toBeTruthy();
  });
});
