export class Parte {

    idParte: number;
    conteudo: String;
    numero: number;
    nome: String;
    idPeca: number;

}