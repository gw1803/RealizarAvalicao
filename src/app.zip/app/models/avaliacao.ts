import { Time } from "@angular/common";

export class Avaliacao {
    idAvaliacao: number;
    tituloAvaliacao: string;
    subtituloAvaliacao: string;
    nomeProfessor: string;
    valorTotal: number;
    tempo: String;
    instrucoes: string;
    numeroTentativas: number;
}
