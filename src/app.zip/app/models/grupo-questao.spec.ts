import { GrupoQuestao } from './grupo-questao';

describe('GrupoQuestao', () => {
  it('should create an instance', () => {
    expect(new GrupoQuestao()).toBeTruthy();
  });
});
